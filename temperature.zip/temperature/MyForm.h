#pragma once

namespace temperature {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	using namespace System::Text::RegularExpressions;

	/// <summary>
	/// ������ ��� MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::TextBox^ equation_textBox;
	protected:
	private: System::Windows::Forms::Button^ result_button;
	private: System::Windows::Forms::Label^ result_label;
	private: System::Windows::Forms::Label^ info_label;
	private: System::Windows::Forms::ComboBox^ temp_scale_comboBox;
	private: System::Windows::Forms::ContextMenuStrip^ math_operation_contextMenuStrip;
	private: System::Windows::Forms::ToolStripMenuItem^ add_ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripTextBox^ add_toolStripTextBox;

	private: System::Windows::Forms::ToolStripMenuItem^ subtract_ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripTextBox^ subtract_toolStripTextBox;

	private: System::Windows::Forms::ToolStripMenuItem^ multiply_ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripTextBox^ multiply_toolStripTextBox;

	private: System::Windows::Forms::ToolStripMenuItem^ share_ToolStripMenuItem;
	private: System::Windows::Forms::ToolStripTextBox^ share_toolStripTextBox;
	private: System::Windows::Forms::Label^ temp_scale_label;
	private: System::Windows::Forms::Label^ equation_label;
	private: System::Windows::Forms::ToolTip^ help_toolTip;




	private: System::ComponentModel::IContainer^ components;





	private:
		/// <summary>
		/// ������������ ���������� ������������.
		/// </summary>


#pragma region Windows Form Designer generated code
		/// <summary>
		/// ��������� ����� ��� ��������� ������������ � �� ��������� 
		/// ���������� ����� ������ � ������� ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->components = (gcnew System::ComponentModel::Container());
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(MyForm::typeid));
			this->equation_textBox = (gcnew System::Windows::Forms::TextBox());
			this->math_operation_contextMenuStrip = (gcnew System::Windows::Forms::ContextMenuStrip(this->components));
			this->add_ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->add_toolStripTextBox = (gcnew System::Windows::Forms::ToolStripTextBox());
			this->subtract_ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->subtract_toolStripTextBox = (gcnew System::Windows::Forms::ToolStripTextBox());
			this->multiply_ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->multiply_toolStripTextBox = (gcnew System::Windows::Forms::ToolStripTextBox());
			this->share_ToolStripMenuItem = (gcnew System::Windows::Forms::ToolStripMenuItem());
			this->share_toolStripTextBox = (gcnew System::Windows::Forms::ToolStripTextBox());
			this->result_button = (gcnew System::Windows::Forms::Button());
			this->result_label = (gcnew System::Windows::Forms::Label());
			this->info_label = (gcnew System::Windows::Forms::Label());
			this->temp_scale_comboBox = (gcnew System::Windows::Forms::ComboBox());
			this->temp_scale_label = (gcnew System::Windows::Forms::Label());
			this->equation_label = (gcnew System::Windows::Forms::Label());
			this->help_toolTip = (gcnew System::Windows::Forms::ToolTip(this->components));
			this->math_operation_contextMenuStrip->SuspendLayout();
			this->SuspendLayout();
			// 
			// equation_textBox
			// 
			this->equation_textBox->ContextMenuStrip = this->math_operation_contextMenuStrip;
			this->equation_textBox->Location = System::Drawing::Point(40, 160);
			this->equation_textBox->MaxLength = 10;
			this->equation_textBox->Name = L"equation_textBox";
			this->equation_textBox->Size = System::Drawing::Size(200, 20);
			this->equation_textBox->TabIndex = 0;
			this->help_toolTip->SetToolTip(this->equation_textBox, resources->GetString(L"equation_textBox.ToolTip"));
			this->equation_textBox->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &MyForm::equation_textBox_KeyPress);
			this->equation_textBox->MouseDown += gcnew System::Windows::Forms::MouseEventHandler(this, &MyForm::equation_textBox_MouseDown);
			// 
			// math_operation_contextMenuStrip
			// 
			this->math_operation_contextMenuStrip->Items->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(4) {
				this->add_ToolStripMenuItem,
					this->subtract_ToolStripMenuItem, this->multiply_ToolStripMenuItem, this->share_ToolStripMenuItem
			});
			this->math_operation_contextMenuStrip->Name = L"math_operation_contextMenuStrip";
			this->math_operation_contextMenuStrip->Size = System::Drawing::Size(135, 92);
			// 
			// add_ToolStripMenuItem
			// 
			this->add_ToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->add_toolStripTextBox });
			this->add_ToolStripMenuItem->Name = L"add_ToolStripMenuItem";
			this->add_ToolStripMenuItem->Size = System::Drawing::Size(134, 22);
			this->add_ToolStripMenuItem->Text = L"���������";
			// 
			// add_toolStripTextBox
			// 
			this->add_toolStripTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9));
			this->add_toolStripTextBox->MaxLength = 10;
			this->add_toolStripTextBox->Name = L"add_toolStripTextBox";
			this->add_toolStripTextBox->Size = System::Drawing::Size(100, 23);
			this->add_toolStripTextBox->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &MyForm::add_toolStripTextBox_KeyPress);
			// 
			// subtract_ToolStripMenuItem
			// 
			this->subtract_ToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->subtract_toolStripTextBox });
			this->subtract_ToolStripMenuItem->Name = L"subtract_ToolStripMenuItem";
			this->subtract_ToolStripMenuItem->Size = System::Drawing::Size(134, 22);
			this->subtract_ToolStripMenuItem->Text = L"�������";
			// 
			// subtract_toolStripTextBox
			// 
			this->subtract_toolStripTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9));
			this->subtract_toolStripTextBox->MaxLength = 10;
			this->subtract_toolStripTextBox->Name = L"subtract_toolStripTextBox";
			this->subtract_toolStripTextBox->Size = System::Drawing::Size(100, 23);
			this->subtract_toolStripTextBox->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &MyForm::subtract_toolStripTextBox_KeyPress);
			// 
			// multiply_ToolStripMenuItem
			// 
			this->multiply_ToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->multiply_toolStripTextBox });
			this->multiply_ToolStripMenuItem->Name = L"multiply_ToolStripMenuItem";
			this->multiply_ToolStripMenuItem->Size = System::Drawing::Size(134, 22);
			this->multiply_ToolStripMenuItem->Text = L"��������";
			// 
			// multiply_toolStripTextBox
			// 
			this->multiply_toolStripTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9));
			this->multiply_toolStripTextBox->MaxLength = 8;
			this->multiply_toolStripTextBox->Name = L"multiply_toolStripTextBox";
			this->multiply_toolStripTextBox->Size = System::Drawing::Size(100, 23);
			this->multiply_toolStripTextBox->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &MyForm::multiply_toolStripTextBox_KeyPress);
			// 
			// share_ToolStripMenuItem
			// 
			this->share_ToolStripMenuItem->DropDownItems->AddRange(gcnew cli::array< System::Windows::Forms::ToolStripItem^  >(1) { this->share_toolStripTextBox });
			this->share_ToolStripMenuItem->Name = L"share_ToolStripMenuItem";
			this->share_ToolStripMenuItem->Size = System::Drawing::Size(134, 22);
			this->share_ToolStripMenuItem->Text = L"��������";
			// 
			// share_toolStripTextBox
			// 
			this->share_toolStripTextBox->Font = (gcnew System::Drawing::Font(L"Segoe UI", 9));
			this->share_toolStripTextBox->MaxLength = 8;
			this->share_toolStripTextBox->Name = L"share_toolStripTextBox";
			this->share_toolStripTextBox->Size = System::Drawing::Size(100, 23);
			this->share_toolStripTextBox->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &MyForm::share_toolStripTextBox_KeyPress);
			// 
			// result_button
			// 
			this->result_button->Location = System::Drawing::Point(150, 250);
			this->result_button->Name = L"result_button";
			this->result_button->Size = System::Drawing::Size(100, 23);
			this->result_button->TabIndex = 1;
			this->result_button->Text = L"�������������";
			this->help_toolTip->SetToolTip(this->result_button, L"�������������� �������������� �������� �� ����� ����� � ������");
			this->result_button->UseVisualStyleBackColor = true;
			this->result_button->Click += gcnew System::EventHandler(this, &MyForm::result_button_Click);
			// 
			// result_label
			// 
			this->result_label->AutoSize = true;
			this->result_label->Location = System::Drawing::Point(40, 200);
			this->result_label->Name = L"result_label";
			this->result_label->Size = System::Drawing::Size(65, 13);
			this->result_label->TabIndex = 2;
			this->result_label->Text = L"���������: ";
			// 
			// info_label
			// 
			this->info_label->AutoSize = true;
			this->info_label->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 14.25F, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->info_label->Location = System::Drawing::Point(40, 20);
			this->info_label->Name = L"info_label";
			this->info_label->Size = System::Drawing::Size(314, 24);
			this->info_label->TabIndex = 3;
			this->info_label->Text = L"������� � ������������� �����";
			// 
			// temp_scale_comboBox
			// 
			this->temp_scale_comboBox->FormattingEnabled = true;
			this->temp_scale_comboBox->Items->AddRange(gcnew cli::array< System::Object^  >(3) { L"�������", L"����������", L"��������" });
			this->temp_scale_comboBox->Location = System::Drawing::Point(40, 100);
			this->temp_scale_comboBox->Name = L"temp_scale_comboBox";
			this->temp_scale_comboBox->Size = System::Drawing::Size(121, 21);
			this->temp_scale_comboBox->TabIndex = 4;
			this->temp_scale_comboBox->Text = L"�������";
			this->temp_scale_comboBox->KeyPress += gcnew System::Windows::Forms::KeyPressEventHandler(this, &MyForm::temp_scale_comboBox_KeyPress);
			// 
			// temp_scale_label
			// 
			this->temp_scale_label->AutoSize = true;
			this->temp_scale_label->Location = System::Drawing::Point(40, 80);
			this->temp_scale_label->Name = L"temp_scale_label";
			this->temp_scale_label->Size = System::Drawing::Size(172, 13);
			this->temp_scale_label->TabIndex = 5;
			this->temp_scale_label->Text = L"�������� ������������� �����";
			// 
			// equation_label
			// 
			this->equation_label->AutoSize = true;
			this->equation_label->Location = System::Drawing::Point(40, 140);
			this->equation_label->Name = L"equation_label";
			this->equation_label->Size = System::Drawing::Size(179, 13);
			this->equation_label->TabIndex = 6;
			this->equation_label->Text = L"������� ������������� ��������";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(384, 311);
			this->Controls->Add(this->equation_label);
			this->Controls->Add(this->temp_scale_label);
			this->Controls->Add(this->temp_scale_comboBox);
			this->Controls->Add(this->info_label);
			this->Controls->Add(this->result_label);
			this->Controls->Add(this->result_button);
			this->Controls->Add(this->equation_textBox);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->MaximizeBox = false;
			this->Name = L"MyForm";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterScreen;
			this->Text = L"������� � ������������� �����";
			this->math_operation_contextMenuStrip->ResumeLayout(false);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

	private:
		// �������� �� �����
		bool is_number(String^ text)
		{
			String^ pattern = "^(?<number>-?[0-9]+(,[0-9]+)?)$";
			Regex^ regex = gcnew Regex(pattern);
			Match^ match = regex->Match(text);

			if (match->Success)
				return true;
			else
				return false;
		}

		// �������� �� �������� �����������
		bool is_temperature(String^ text)
		{
			String^ pattern = "^(?<temperature>-?[0-9]+(,[0-9]+)?)_(?<scale>deg|K|f)$";
			Regex^ regex = gcnew Regex(pattern);
			Match^ match = regex->Match(text);

			if (match->Success)
				return true;
			else
				return false;
		}

		// ����� ������������� �����
		String^ which_temp_scale(String^ text)
		{
			String^ pattern = "^(?<temperature>-?[0-9]+(,[0-9]+)?)_(?<scale>deg|K|f)$";
			Regex^ regex = gcnew Regex(pattern);
			Match^ match = regex->Match(text);

			if (match->Success)
				return match->Groups["scale"]->Value;
			else
				return "";
		}

		// ������� �� ����� ������������� ����� � ������
		double to_temperature_scale(String^ value, String^ t_scale_conversion)
		{
			String^ pattern = "^(?<temperature>-?[0-9]+(,[0-9]+)?)_(?<t_scale>deg|K|f)$";
			Regex^ regex = gcnew Regex(pattern);
			Match^ match = regex->Match(value);
			String^ t_scale = match->Groups["t_scale"]->Value;
			double temperature = Convert::ToDouble(match->Groups["temperature"]->Value);

			if (match->Success)
			{
				if (t_scale != t_scale_conversion)
				{
					if (t_scale == "K")
						temperature -= 273.15;
					else if (t_scale == "f")
						temperature = (temperature - 32) / 1.8;

					if (t_scale_conversion == "K")
						temperature += 273.15;
					else if (t_scale_conversion == "f")
						temperature = (temperature * 1.8) + 32;
				}

				return temperature;
			}
			else
				return 0;
		}

		
	private: System::Void result_button_Click(System::Object^ sender, System::EventArgs^ e) {
		String^ equation = equation_textBox->Text;
		double result = 0;

		if (is_temperature(equation))
		{
			if (temp_scale_comboBox->Text == "�������")
			{
				result = to_temperature_scale(equation, "deg");
				result_label->Text = ("���������: " + Math::Round(result, 2) + " deg");
			}
			else if (temp_scale_comboBox->Text == "��������")
			{
				result = to_temperature_scale(equation, "K");
				result_label->Text = ("���������: " + Math::Round(result, 2) + " K");
			}
			else if (temp_scale_comboBox->Text == "����������")
			{
				result = to_temperature_scale(equation, "f");
				result_label->Text = ("���������: " + Math::Round(result, 2) + " f");
			}
		}
		else
			result_label->Text = "������� �� �������� �����������";
	}

	// ��� ������� ������ � textbox

	private: System::Void equation_textBox_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {
		if (e->KeyChar == 13) // ��� ������� �� enter
			result_button_Click(sender, e);
	}

	private: System::Void add_toolStripTextBox_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {
		if (e->KeyChar == 13) // ��� ������� �� enter
		{
			if (is_temperature(equation_textBox->Text) && is_temperature(add_toolStripTextBox->Text))
			{
				double first_temp = to_temperature_scale(equation_textBox->Text, which_temp_scale(equation_textBox->Text));
				double second_temp = to_temperature_scale(add_toolStripTextBox->Text, which_temp_scale(equation_textBox->Text));

				equation_textBox->Text = Convert::ToString(Math::Round(first_temp + second_temp, 2)) + "_" + which_temp_scale(equation_textBox->Text);
			}
		}
	}

	private: System::Void subtract_toolStripTextBox_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {
		if (e->KeyChar == 13) // ��� ������� �� enter
		{
			if (is_temperature(equation_textBox->Text) && is_temperature(subtract_toolStripTextBox->Text))
			{
				double first_temp = to_temperature_scale(equation_textBox->Text, which_temp_scale(equation_textBox->Text));
				double second_temp = to_temperature_scale(subtract_toolStripTextBox->Text, which_temp_scale(equation_textBox->Text));

				equation_textBox->Text = Convert::ToString(Math::Round(first_temp - second_temp, 2)) + "_" + which_temp_scale(equation_textBox->Text);
			}
		}
	}
	
	private: System::Void multiply_toolStripTextBox_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {
		if (e->KeyChar == 13) // ��� ������� �� enter
		{
			if (is_temperature(equation_textBox->Text) && is_number(multiply_toolStripTextBox->Text))
			{
				double temp = to_temperature_scale(equation_textBox->Text, which_temp_scale(equation_textBox->Text));
				double number = Convert::ToDouble(multiply_toolStripTextBox->Text);

				equation_textBox->Text = Convert::ToString(Math::Round(temp * number, 2)) + "_" + which_temp_scale(equation_textBox->Text);
			}
		}
	}

	private: System::Void share_toolStripTextBox_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {
		if (e->KeyChar == 13) // ��� ������� �� enter
		{
			if (is_temperature(equation_textBox->Text) && is_number(share_toolStripTextBox->Text))
			{
				double temp = to_temperature_scale(equation_textBox->Text, which_temp_scale(equation_textBox->Text));
				double number = Convert::ToDouble(share_toolStripTextBox->Text);

				equation_textBox->Text = Convert::ToString(Math::Round(temp / number, 2)) + "_" + which_temp_scale(equation_textBox->Text);
			}
		}
	}

	// ������ �� ���� �������� ��� ������ ������������� �����
	private: System::Void temp_scale_comboBox_KeyPress(System::Object^ sender, System::Windows::Forms::KeyPressEventArgs^ e) {
		if (e->KeyChar != 0)
			e->KeyChar = 0;
	}

	// ��� ������� �� ������ ����
	private: System::Void equation_textBox_MouseDown(System::Object^ sender, System::Windows::Forms::MouseEventArgs^ e) {
		if ((e->Button == Windows::Forms::MouseButtons::Right) && (is_temperature(equation_textBox->Text)))
			math_operation_contextMenuStrip->Enabled = true;
		else if (!is_temperature(equation_textBox->Text))
			math_operation_contextMenuStrip->Enabled = false;
	}
};
}
